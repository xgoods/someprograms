﻿'Brian Goodwin
Imports System.Data.OleDb

Public Class Form1
    Dim connStr As String
    Dim dt As New DataTable
    Dim ds As New DataSet

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connStr = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=C:\Users\b\Downloads\MEGACITIES.MDB"
        Dim sqlStr = "Select * From Cities"
        Dim dataAdapter As New OleDb.OleDbDataAdapter(sqlStr, connStr)
        dataAdapter.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        connStr = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=C:\Users\b\Downloads\MEGACITIES.MDB"
        Dim changes As Integer
        Dim sqlStr1 As String = "SELECT * From Cities"

        Dim dataAdapter As New OleDb.OleDbDataAdapter(sqlStr1, connStr)
        Dim commandBuilder As New OleDb.OleDbCommandBuilder(dataAdapter)

        changes = dataAdapter.Update(dt)
        dataAdapter.Dispose()
        If changes > 0 Then
            MsgBox("Changes saved")
        Else
            MsgBox("No Changes made")


        End If


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        connStr = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=C:\Users\b\Downloads\MEGACITIES.MDB"
        Dim search As String = TextBox1.Text
        Dim sqlStr = "Select * From Cities"
        Dim sqlStr3 As String = "SELECT * FROM Cities WHERE Cities.country='" & search & "'"
        Dim dataAdapter As New OleDb.OleDbDataAdapter(sqlStr3, connStr)
        Dim dataAdapter2 As New OleDb.OleDbDataAdapter(sqlStr, connStr)
        dt.Clear()
        dataAdapter.Fill(dt)
        DataGridView1.DataSource = dt

        If search = String.Empty Then

            dataAdapter2.Fill(dt)
            DataGridView1.DataSource = dt
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DataGridView1.Sort(DataGridView1.Columns(3), System.ComponentModel.ListSortDirection.Ascending)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        connStr = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=C:\Users\b\Downloads\MEGACITIES.MDB"
        Dim sqlStr4 As String = "SELECT * FROM Cities INNER JOIN Countries ON Cities.country = Countries.country WHERE currency"
        Dim dataAdapter As New OleDb.OleDbDataAdapter(sqlStr4, connStr)
        dt.Clear()
        dataAdapter.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub
End Class
