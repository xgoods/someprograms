﻿'Brian Goodwin
'CPT341 online
Imports System.Drawing.Drawing2D
Imports System.Collections
Public Class Form1
    Dim PopData As New ArrayList(100)


    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click



    End Sub
    Private Sub DrawChart()
        Dim g As Graphics
        Dim bmap As Bitmap
        bmap = New Bitmap(PictureBox1.Width, PictureBox1.Height, PictureBox1.CreateGraphics)
        g = Graphics.FromImage(bmap)
        PictureBox1.Image = bmap

        Dim LeftMargin As Integer = 35
        Dim RightMargin As Integer = 15
        Dim BaseMargin As Integer = 35
        Dim TopMargin As Integer = 10
        Dim BarGap As Integer = 12
        Dim StartPoint As New Point(LeftMargin, PictureBox1.Height - BaseMargin)
        Dim EndPoint As New Point(LeftMargin, TopMargin)
        Dim LinePen As New Pen(Color.Black, 2)

        Dim VertLineLength As Integer = PictureBox1.Height - (BaseMargin + TopMargin)
        Dim VertGap As Integer = CInt(VertLineLength / 10)
        Dim TickSP As New Point(LeftMargin - 5, StartPoint.Y - VertGap)
        Dim TickEP As New Point(LeftMargin, StartPoint.Y - VertGap)
        Dim ValueFont As New Font("Arial", 8, FontStyle.Regular)
        g.DrawLine(LinePen, StartPoint, EndPoint)
        For i As Integer = 1 To 10
            g.DrawLine(New Pen(Color.Black), TickSP, TickEP)
            g.DrawString(CStr(i * 100), ValueFont, Brushes.Black, 2, TickSP.Y - 5)
            TickSP.Y -= VertGap
            TickEP.Y -= VertGap
        Next

        g.DrawLine(LinePen, LeftMargin, PictureBox1.Height - BaseMargin, PictureBox1.Width - RightMargin, PictureBox1.Height - BaseMargin)
        Dim BaseLineLength As Integer = PictureBox1.Width - (LeftMargin + RightMargin)
        Dim BarWidth As Double = (BaseLineLength / PopData.Count) - BarGap
        Dim BarRect As Rectangle
        Dim BarStartX As Integer = LeftMargin + BarGap
        Dim BarStartY As Integer = PictureBox1.Height - (BaseMargin + 1)
        Dim BarBrush As New SolidBrush(Color.BurlyWood)
        Dim VertScale As Double = VertLineLength / 1000

        For Each gd As GraphData In PopData
            Dim BarHeight As Integer = CInt(gd.Population * VertScale)
            BarRect = New Rectangle(BarStartX, BarStartY, CInt(BarWidth), BarHeight)
            BarRect.Offset(0, -BarHeight)
            g.FillRectangle(BarBrush, BarRect)
            g.DrawRectangle(LinePen, BarRect)
            BarStartX += CInt(BarWidth + BarGap)

        Next

        Dim TextStartX As Integer = LeftMargin + BarGap + 4
        Dim TextBrush As Brush = New SolidBrush(Color.Black)
        Dim TextFont As New Font("Arial", 11, FontStyle.Bold)

        For Each gd As GraphData In PopData
            g.DrawString(gd.Country, TextFont, TextBrush, TextStartX, CInt(PictureBox1.Height - (BaseMargin - 4)))
            TextStartX += CInt(BarWidth + BarGap)
        Next



        g.Dispose()
        LinePen.Dispose()
    End Sub
    Structure GraphData
        Dim Country As String
        Dim Population As Short
        Sub New(ByVal country As String, ByVal population As Short)
            Me.Country = country
            Me.Population = population
        End Sub
    End Structure

    Private Sub GetData()
        PopData.clear()
        PopData.Add(New GraphData("U.S.", 321.3))
        PopData.Add(New GraphData("Japan", 126.9))
        PopData.Add(New GraphData("Russia", 143.5))
        PopData.Add(New GraphData("Brazil", 204.2))
        PopData.Add(New GraphData("Pakistan", 199.08))
        PopData.Add(New GraphData("Mexico", 121.7))

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        GetData()
        DrawChart()
    End Sub
End Class
