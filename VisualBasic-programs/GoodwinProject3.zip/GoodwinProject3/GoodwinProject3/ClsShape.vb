﻿Public Class ClsShape

    Public base As Double
    Public height As Double
    Public diameter As Double

End Class
