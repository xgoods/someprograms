﻿Public Class ClsSquare
    Inherits ClsShape

    Public centX As New Double
    Public centY As New Double
    Public area As New Double



    Public Function getCentX()
        centX = base * 0.5
        Return centX
    End Function

    Public Function getCentY()
        centY = height * 0.5
        Return centY
    End Function

    Public Function getArea()
        area = base * height
        Return area

    End Function







End Class
