﻿Public Class ClsCircle
    Inherits ClsShape

    Public centX As New Double
    Public centY As New Double
    Public area As New Double

    Public Function getCentX()
        centX = 0.5 * diameter
        Return centX
    End Function

    Public Function getCentY()
        centY = 0.5 * diameter
        Return centY
    End Function

    Public Function getArea()
        area = Math.PI * diameter
        Return area

    End Function
End Class
