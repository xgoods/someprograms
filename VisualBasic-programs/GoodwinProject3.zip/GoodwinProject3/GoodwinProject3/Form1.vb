﻿Public Class Form1
    Private Sub TextBox12_TextChanged(sender As Object, e As EventArgs) Handles TextBox12.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim objSquare As New ClsSquare
        Dim objTriangle As New ClsTriangle
        Dim objCircle As New ClsCircle

        If TextBox1.Text = String.Empty Then
            objSquare.base = "0"
            objTriangle.base = "0"
        Else
            Try
                objSquare.base = TextBox1.Text
                objTriangle.base = TextBox1.Text
            Catch ex As Exception
                MsgBox("the base must be numeric")
            Finally
                If TextBox1.Text < 0 Then
                    MsgBox("Base cannot be negative")
                End If
            End Try
        End If

        If TextBox2.Text = String.Empty Then
            objSquare.height = "0"
            objTriangle.height = "0"
        Else

            Try
                objSquare.height = TextBox2.Text
                objTriangle.height = TextBox2.Text
            Catch ex As Exception
                MsgBox("the height must be numeric")
            Finally
                If TextBox2.Text < 0 Then
                    MsgBox("Height cannot be negative")
                End If
            End Try
        End If

        If TextBox1.Text = String.Empty And Not TextBox2.Text = String.Empty Then
            MsgBox("Youre missing a base value")

            Try
                objSquare.base = TextBox1.Text
                objTriangle.base = TextBox1.Text
            Catch ex As Exception
                MsgBox("the base must be numeric")
            Finally
                If TextBox1.Text < 0 Then
                    MsgBox("Base cannot be negative")
                End If
            End Try
        End If

        If TextBox2.Text = String.Empty And Not TextBox1.Text = String.Empty Then
            MsgBox("Youre missing a height value")

            Try
                objSquare.base = TextBox1.Text
                objTriangle.base = TextBox1.Text
            Catch ex As Exception
                MsgBox("the base must be numeric")
            Finally
                If Val(TextBox2.Text) < 0 Then
                    MsgBox("Base cannot be negative")
                End If
            End Try
        End If

        If TextBox3.Text = String.Empty Then
            objCircle.diameter = "0"
        Else
            Try
                objCircle.diameter = TextBox3.Text
            Catch ex As Exception
                MsgBox("the diameter must be numeric")
            Finally
                If TextBox3.Text < 0 Then
                    MsgBox("The diameter cannot be negative")

                End If
            End Try
        End If



        TextBox4.Text = Format(Val(objSquare.getCentX()), "0.00")
        TextBox5.Text = Format(Val(objSquare.getCentY()), "0.00")
        TextBox6.Text = Format(Val(objSquare.getArea()), "0.00")

        TextBox7.Text = Format(Val(objTriangle.getCentX()), "0.00")
        TextBox8.Text = Format(Val(objTriangle.getCentY()), "0.00")
        TextBox9.Text = Format(Val(objTriangle.getArea()), "0.00")

        TextBox10.Text = Format(Val(objCircle.getCentX()), "0.00")
        TextBox11.Text = Format(Val(objCircle.getCentX()), "0.00")
        TextBox12.Text = Format(Val(objCircle.getArea()), "0.00")


    End Sub
End Class
