﻿Imports System.IO
Public Class Form1
    Dim myChars() As Char

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)
        ComboBox1.Items.Add("87241")
        ComboBox1.Items.Add("67918")
        ComboBox1.Items.Add("13243")
        ComboBox1.Items.Add("92367")

    End Sub

    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim textFile As IO.StreamReader
        Dim strInput As String

        OpenFileDialog1.ShowDialog()
        Try
            textFile = IO.File.OpenText(OpenFileDialog1.FileName)
        Catch ex As Exception
            MsgBox("File not found.", MessageBoxIcon.Error, "Error")
            Environment.Exit(0)


        Finally
            Do While textFile.Peek <> -1
                strInput = textFile.ReadLine()
                RichTextBox1.Text = strInput
                myChars = (strInput.ToCharArray())
            Loop

        End Try



    End Sub

    Public Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub

    Public Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click


        Dim count As Integer = 0
        Dim nextCount As Integer = 0
        Dim keyCount As Integer = 0
        Dim nextKeyCount As Integer = 0
        Dim select1() = New Integer() {8, 7, 2, 4, 1}
        Dim select2() = New Integer() {6, 7, 9, 1, 8}
        Dim select3() = New Integer() {1, 3, 2, 4, 3}
        Dim select4() = New Integer() {9, 2, 3, 6, 7}
        Dim encrypted() As Integer
        Dim encryptResult As String
        Dim encryptedMSG() As String
        Dim decrypted() As Integer
        Dim decryptedResult As String
        Dim decryptedMSG() As String
        Dim stdIn As String
        Dim encryptedFile As StreamWriter

        If Not RichTextBox1.Text = String.Empty Then
            stdIn = RichTextBox1.Text
            myChars = (stdIn.ToCharArray())
        End If

        ReDim encrypted(myChars.Length - 1)
        ReDim decrypted(myChars.Length - 1)

        If ComboBox1.SelectedItem = "87241" Then
            For i As Integer = 0 To myChars.GetUpperBound(0)

                If count < 4 Then
                    encrypted(i) = Asc(myChars(i)) + select1(keyCount)

                    If encrypted(i) > 126 Then
                        encrypted(i) = 32
                    End If
                End If
                If count = 4 Then

                    encrypted(i) = Asc(myChars(i)) + (select1(keyCount))
                    If encrypted(i) > 126 Then
                        encrypted(i) = 32
                    End If
                    count = -1
                    keyCount = -1
                End If
                count += 1
                keyCount += 1
            Next
            ReDim encryptedMSG(myChars.Length - 1)
            For i As Integer = 0 To myChars.GetUpperBound(0)
                encryptedMSG(i) = Chr(encrypted(i))
            Next

            encryptResult = String.Join("", encryptedMSG.ToArray())
            RichTextBox2.Text = encryptResult
            Try
                encryptedFile = File.CreateText("EncryptedFile.txt")
                encryptedFile.Write(encryptResult)
            Catch
                MsgBox("File not created.", MessageBoxIcon.Error, "Error")

            Finally
                encryptedFile.Close()
            End Try

            For i As Integer = 0 To encryptedMSG.GetUpperBound(0)

                If nextCount < 4 Then
                    decrypted(i) = ((encrypted(i)) - (select1(nextKeyCount)))

                End If
                If nextCount = 4 Then
                    decrypted(i) = (encrypted(i)) - (select1(nextKeyCount))
                    nextCount = -1
                    nextKeyCount = -1

                End If
                nextCount += 1
                nextKeyCount += 1
            Next
            ReDim decryptedMSG(myChars.Length - 1)
            For i As Integer = 0 To myChars.GetUpperBound(0)
                decryptedMSG(i) = Chr(decrypted(i))
            Next

            decryptedResult = String.Join("", decryptedMSG.ToArray())
            Label5.Text = (decryptedResult)
        End If

        If ComboBox1.SelectedItem = "67918" Then
            For i As Integer = 0 To myChars.GetUpperBound(0)

                If count < 4 Then
                    encrypted(i) = Asc(myChars(i)) + select2(keyCount)
                    If encrypted(i) > 126 Then
                        encrypted(i) = 32
                    End If
                End If
                If count = 4 Then

                    encrypted(i) = Asc(myChars(i)) + (select2(keyCount))
                    If encrypted(i) > 126 Then
                        encrypted(i) = 32
                    End If
                    count = -1
                    keyCount = -1
                End If
                count += 1
                keyCount += 1
            Next
            ReDim encryptedMSG(myChars.Length - 1)
            For i As Integer = 0 To myChars.GetUpperBound(0)
                encryptedMSG(i) = Chr(encrypted(i))
            Next

            encryptResult = String.Join("", encryptedMSG.ToArray())
            RichTextBox2.Text = encryptResult
            Try
                encryptedFile = File.CreateText("EncryptedFile.txt")
                encryptedFile.Write(encryptResult)
            Catch
                MsgBox("File not created", MessageBoxIcon.Error, "Error")

            Finally
                encryptedFile.Close()
            End Try

            For i As Integer = 0 To encryptedMSG.GetUpperBound(0)

                If nextCount < 4 Then
                    decrypted(i) = ((encrypted(i)) - (select2(nextKeyCount)))

                End If
                If nextCount = 4 Then
                    decrypted(i) = (encrypted(i)) - (select2(nextKeyCount))
                    nextCount = -1
                    nextKeyCount = -1

                End If
                nextCount += 1
                nextKeyCount += 1
            Next
            ReDim decryptedMSG(myChars.Length - 1)
            For i As Integer = 0 To myChars.GetUpperBound(0)
                decryptedMSG(i) = Chr(decrypted(i))
            Next

            decryptedResult = String.Join("", decryptedMSG.ToArray())
            Label5.Text = (decryptedResult)
        End If

        If ComboBox1.SelectedItem = "13243" Then
            For i As Integer = 0 To myChars.GetUpperBound(0)

                If count < 4 Then
                    encrypted(i) = Asc(myChars(i)) + select3(keyCount)
                    If encrypted(i) > 126 Then
                        encrypted(i) = 32
                    End If
                End If
                If count = 4 Then
                    If encrypted(i) > 126 Then
                        encrypted(i) = 32
                    End If
                    encrypted(i) = Asc(myChars(i)) + (select3(keyCount))
                    count = -1
                    keyCount = -1
                End If
                count += 1
                keyCount += 1
            Next
            ReDim encryptedMSG(myChars.Length - 1)
            For i As Integer = 0 To myChars.GetUpperBound(0)
                encryptedMSG(i) = Chr(encrypted(i))
            Next

            encryptResult = String.Join("", encryptedMSG.ToArray())
            RichTextBox2.Text = encryptResult
            Try
                encryptedFile = File.CreateText("EncryptedFile.txt")
                encryptedFile.Write(encryptResult)
            Catch
                MsgBox("File not created.", MessageBoxIcon.Error, "Error")

            Finally
                encryptedFile.Close()
            End Try

            For i As Integer = 0 To encryptedMSG.GetUpperBound(0)

                If nextCount < 4 Then
                    decrypted(i) = ((encrypted(i)) - (select3(nextKeyCount)))

                End If
                If nextCount = 4 Then
                    decrypted(i) = (encrypted(i)) - (select3(nextKeyCount))
                    nextCount = -1
                    nextKeyCount = -1

                End If
                nextCount += 1
                nextKeyCount += 1
            Next
            ReDim decryptedMSG(myChars.Length - 1)
            For i As Integer = 0 To myChars.GetUpperBound(0)
                decryptedMSG(i) = Chr(decrypted(i))
            Next

            decryptedResult = String.Join("", decryptedMSG.ToArray())
            Label5.Text = (decryptedResult)
        End If

        If ComboBox1.SelectedItem = "92367" Then
            For i As Integer = 0 To myChars.GetUpperBound(0)

                If count < 4 Then
                    encrypted(i) = Asc(myChars(i)) + select4(keyCount)
                    If encrypted(i) > 126 Then
                        encrypted(i) = 32
                    End If
                End If
                If count = 4 Then

                    encrypted(i) = Asc(myChars(i)) + select4(keyCount)
                    If encrypted(i) > 126 Then
                        encrypted(i) = 32
                    End If
                    count = -1
                    keyCount = -1
                End If
                count += 1
                keyCount += 1
            Next
            ReDim encryptedMSG(myChars.Length - 1)
            For i As Integer = 0 To myChars.GetUpperBound(0)
                encryptedMSG(i) = Chr(encrypted(i))
            Next

            encryptResult = String.Join("", encryptedMSG.ToArray())
            RichTextBox2.Text = encryptResult
            Try
                encryptedFile = File.CreateText("EncryptedFile.txt")
                encryptedFile.Write(encryptResult)
            Catch
                MsgBox("File not created.", MessageBoxIcon.Error, "Error")

            Finally
                encryptedFile.Close()
            End Try

            For i As Integer = 0 To encryptedMSG.GetUpperBound(0)

                If nextCount < 4 Then
                    decrypted(i) = ((encrypted(i)) - (select4(nextKeyCount)))

                End If
                If nextCount = 4 Then
                    decrypted(i) = (encrypted(i)) - (select4(nextKeyCount))
                    nextCount = -1
                    nextKeyCount = -1

                End If
                nextCount += 1
                nextKeyCount += 1
            Next
            ReDim decryptedMSG(myChars.Length - 1)
            For i As Integer = 0 To myChars.GetUpperBound(0)
                decryptedMSG(i) = Chr(decrypted(i))
            Next

            decryptedResult = String.Join("", decryptedMSG.ToArray())
            Label5.Text = (decryptedResult)
        End If

    End Sub
End Class
