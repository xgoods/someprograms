﻿'Brian Goodwin
'2-7-2016
'CPT341
<Global.
    Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.txtGrade1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.txtGrade2 = New System.Windows.Forms.TextBox()
        Me.txtGrade3 = New System.Windows.Forms.TextBox()
        Me.txtGrade4 = New System.Windows.Forms.TextBox()
        Me.txtGrade5 = New System.Windows.Forms.TextBox()
        Me.txtGrade6 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtMean = New System.Windows.Forms.TextBox()
        Me.txtVariance = New System.Windows.Forms.TextBox()
        Me.txtSD = New System.Windows.Forms.TextBox()
        Me.txtLG = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.label11 = New System.Windows.Forms.Label()
        Me.grade1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.grade2 = New System.Windows.Forms.ToolTip(Me.components)
        Me.grade3 = New System.Windows.Forms.ToolTip(Me.components)
        Me.grade4 = New System.Windows.Forms.ToolTip(Me.components)
        Me.grade5 = New System.Windows.Forms.ToolTip(Me.components)
        Me.grade6 = New System.Windows.Forms.ToolTip(Me.components)
        Me.calculate = New System.Windows.Forms.ToolTip(Me.components)
        Me.mean = New System.Windows.Forms.ToolTip(Me.components)
        Me.variance = New System.Windows.Forms.ToolTip(Me.components)
        Me.SD = New System.Windows.Forms.ToolTip(Me.components)
        Me.LG = New System.Windows.Forms.ToolTip(Me.components)
        Me.Label12 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtGrade1
        '
        Me.txtGrade1.Location = New System.Drawing.Point(66, 115)
        Me.txtGrade1.Name = "txtGrade1"
        Me.txtGrade1.Size = New System.Drawing.Size(112, 21)
        Me.txtGrade1.TabIndex = 0
        Me.grade1.SetToolTip(Me.txtGrade1, "Enter Grade 1 here")
        '
        'Label1
        '
        Me.Label1.AccessibleName = ""
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label1.Location = New System.Drawing.Point(184, 119)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Grade 1"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.label2.Location = New System.Drawing.Point(136, 9)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(302, 45)
        Me.label2.TabIndex = 2
        Me.label2.Text = "Grade Calculator"
        '
        'txtGrade2
        '
        Me.txtGrade2.Location = New System.Drawing.Point(66, 142)
        Me.txtGrade2.Name = "txtGrade2"
        Me.txtGrade2.Size = New System.Drawing.Size(112, 21)
        Me.txtGrade2.TabIndex = 3
        Me.grade2.SetToolTip(Me.txtGrade2, "Enter Grade 2 here")
        '
        'txtGrade3
        '
        Me.txtGrade3.Location = New System.Drawing.Point(66, 169)
        Me.txtGrade3.Name = "txtGrade3"
        Me.txtGrade3.Size = New System.Drawing.Size(112, 21)
        Me.txtGrade3.TabIndex = 4
        Me.grade3.SetToolTip(Me.txtGrade3, "Enter Grade 3 here")
        '
        'txtGrade4
        '
        Me.txtGrade4.Location = New System.Drawing.Point(66, 196)
        Me.txtGrade4.Name = "txtGrade4"
        Me.txtGrade4.Size = New System.Drawing.Size(112, 21)
        Me.txtGrade4.TabIndex = 5
        Me.grade4.SetToolTip(Me.txtGrade4, "Enter Grade 4 here")
        '
        'txtGrade5
        '
        Me.txtGrade5.Location = New System.Drawing.Point(66, 223)
        Me.txtGrade5.Name = "txtGrade5"
        Me.txtGrade5.Size = New System.Drawing.Size(112, 21)
        Me.txtGrade5.TabIndex = 6
        Me.grade5.SetToolTip(Me.txtGrade5, "Enter Grade 5 here")
        '
        'txtGrade6
        '
        Me.txtGrade6.Location = New System.Drawing.Point(66, 250)
        Me.txtGrade6.Name = "txtGrade6"
        Me.txtGrade6.Size = New System.Drawing.Size(112, 21)
        Me.txtGrade6.TabIndex = 7
        Me.grade6.SetToolTip(Me.txtGrade6, "Enter Grade 6 here")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label3.Location = New System.Drawing.Point(184, 200)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Grade 4"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label4.Location = New System.Drawing.Point(184, 146)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Grade 2"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label5.Location = New System.Drawing.Point(184, 227)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Grade 5"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label6.Location = New System.Drawing.Point(184, 254)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Grade 6"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label7.Location = New System.Drawing.Point(184, 173)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Grade 3"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(321, 132)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(200, 94)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Calculate"
        Me.calculate.SetToolTip(Me.Button1, "Click to calculate")
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtMean
        '
        Me.txtMean.Location = New System.Drawing.Point(66, 355)
        Me.txtMean.Name = "txtMean"
        Me.txtMean.Size = New System.Drawing.Size(112, 21)
        Me.txtMean.TabIndex = 14
        Me.mean.SetToolTip(Me.txtMean, "Result")
        '
        'txtVariance
        '
        Me.txtVariance.Location = New System.Drawing.Point(66, 382)
        Me.txtVariance.Name = "txtVariance"
        Me.txtVariance.Size = New System.Drawing.Size(112, 21)
        Me.txtVariance.TabIndex = 15
        Me.variance.SetToolTip(Me.txtVariance, "Result")
        '
        'txtSD
        '
        Me.txtSD.Location = New System.Drawing.Point(66, 409)
        Me.txtSD.Name = "txtSD"
        Me.txtSD.Size = New System.Drawing.Size(112, 21)
        Me.txtSD.TabIndex = 16
        '
        'txtLG
        '
        Me.txtLG.Location = New System.Drawing.Point(66, 436)
        Me.txtLG.Name = "txtLG"
        Me.txtLG.Size = New System.Drawing.Size(112, 21)
        Me.txtLG.TabIndex = 17
        Me.LG.SetToolTip(Me.txtLG, "Result")
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label8.Location = New System.Drawing.Point(184, 355)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 13)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Mean"
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label9.ForeColor = System.Drawing.Color.DodgerBlue
        Me.label9.Location = New System.Drawing.Point(184, 386)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(57, 13)
        Me.label9.TabIndex = 19
        Me.label9.Text = "Variance"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label10.Location = New System.Drawing.Point(184, 413)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(116, 13)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Standard Deviation"
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label11.ForeColor = System.Drawing.Color.DodgerBlue
        Me.label11.Location = New System.Drawing.Point(184, 440)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(78, 13)
        Me.label11.TabIndex = 21
        Me.label11.Text = "Letter Grade"
        '
        'grade1
        '
        Me.grade1.ToolTipTitle = "ToolTip:"
        '
        'grade2
        '
        Me.grade2.ToolTipTitle = "ToolTip:"
        '
        'grade3
        '
        Me.grade3.ToolTipTitle = "ToolTip:"
        '
        'grade4
        '
        Me.grade4.ToolTipTitle = "ToolTip:"
        '
        'grade5
        '
        Me.grade5.ToolTipTitle = "ToolTip:"
        '
        'grade6
        '
        Me.grade6.ToolTipTitle = "ToolTip:"
        '
        'calculate
        '
        Me.calculate.ToolTipTitle = "ToolTip:"
        '
        'mean
        '
        Me.mean.ToolTipTitle = "ToolTip:"
        '
        'variance
        '
        Me.variance.ToolTipTitle = "ToolTip:"
        '
        'SD
        '
        Me.SD.ToolTipTitle = "Result"
        '
        'LG
        '
        Me.LG.ToolTipTitle = "ToolTip:"
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label12.Location = New System.Drawing.Point(211, 54)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(238, 25)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Use it to calculate grades"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(321, 293)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(200, 194)
        Me.PictureBox1.TabIndex = 23
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AccessibleDescription = ""
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(587, 531)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtLG)
        Me.Controls.Add(Me.txtSD)
        Me.Controls.Add(Me.txtVariance)
        Me.Controls.Add(Me.txtMean)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtGrade6)
        Me.Controls.Add(Me.txtGrade5)
        Me.Controls.Add(Me.txtGrade4)
        Me.Controls.Add(Me.txtGrade3)
        Me.Controls.Add(Me.txtGrade2)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtGrade1)
        Me.Font = New System.Drawing.Font("Century Schoolbook", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Name = "Form1"
        Me.Text = "Grade Calculator"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtGrade1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents label2 As Label
    Friend WithEvents txtGrade2 As TextBox
    Friend WithEvents txtGrade3 As TextBox
    Friend WithEvents txtGrade4 As TextBox
    Friend WithEvents txtGrade5 As TextBox
    Friend WithEvents txtGrade6 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents txtMean As TextBox
    Friend WithEvents txtVariance As TextBox
    Friend WithEvents txtSD As TextBox
    Friend WithEvents txtLG As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents label11 As Label
    Friend WithEvents grade1 As ToolTip
    Friend WithEvents grade2 As ToolTip
    Friend WithEvents grade3 As ToolTip
    Friend WithEvents grade4 As ToolTip
    Friend WithEvents grade5 As ToolTip
    Friend WithEvents grade6 As ToolTip
    Friend WithEvents calculate As ToolTip
    Friend WithEvents mean As ToolTip
    Friend WithEvents variance As ToolTip
    Friend WithEvents LG As ToolTip
    Friend WithEvents SD As ToolTip
    Friend WithEvents Label12 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
