﻿'Brian Goodwin
'2-7-2016
'CPT341
Imports System.Math
Public Class Form1
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtGrade1.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles txtGrade5.TextChanged

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim grades(0 To 5) As Double 'holds grades 1-6
        Dim gradesSquared(0 To 5) As Double 'holds grades squared 1-6 
        Dim total As Double 'holds total of grades
        Dim totalSquared As Double 'holds total squared of grades
        Dim totalSquaredSUM As Double 'holds the sum of the squared total 
        Dim totalSquaredDIV As Double 'holds the of the squared total divided by total grades
        Dim mean As Double 'holds the mean
        Dim variance As Double 'holds the variance
        Dim SD As Double 'holds the standard deviation
        Dim LG As String 'holds the letter grade

        'This try block tests number exception for grade 1
        Try
            grades(0) = txtGrade1.Text
        Catch ex As Exception
            MsgBox("Only numbers are allowed", MessageBoxIcon.Error, "Error")
        End Try
        'This statements tests to see if user entered negative grade value for grade 1
        If (grades(0) < 0) Then
            MsgBox("A grade cannot be negative", MessageBoxIcon.Error, "Error")
        End If

        'This try block tests number exception for grade 2
        Try
            grades(1) = txtGrade2.Text
        Catch ex As Exception
            MsgBox("Only numbers are allowed", MessageBoxIcon.Error, "Error")
        End Try
        'This statements tests to see if user entered negative grade value for grade 2
        If (grades(1) < 0) Then
            MsgBox("A grade cannot be negative", MessageBoxIcon.Error, "Error")
        End If

        'This try block tests number exception for grade 3
        Try
            grades(2) = txtGrade3.Text
        Catch ex As Exception
            MsgBox("Only numbers are allowed", MessageBoxIcon.Error, "Error")
        End Try
        'This statements tests to see if user entered negative grade value for grade 3
        If (grades(2) < 0) Then
            MsgBox("A grade cannot be negative", MessageBoxIcon.Error, "Error")
        End If

        'This try block tests number exception for grade 4
        Try
            grades(3) = txtGrade4.Text
        Catch ex As Exception
            MsgBox("Only numbers are allowed", MessageBoxIcon.Error, "Error")
        End Try
        'This statements tests to see if user entered negative grade value for grade 4
        If (grades(3) < 0) Then
            MsgBox("A grade cannot be negative", MessageBoxIcon.Error, "Error")
        End If
        'This try block tests number exception for grade 5

        Try
            grades(4) = txtGrade5.Text
        Catch ex As Exception
            MsgBox("Only numbers are allowed", MessageBoxIcon.Error, "Error")
        End Try
        'This statements tests to see if user entered negative grade value for grade 5
        If (grades(4) < 0) Then
            MsgBox("A grade cannot be negative", MessageBoxIcon.Error, "Error")
        End If

        'This try block tests number exception for grade 6
        Try
            grades(5) = txtGrade6.Text
        Catch ex As Exception
            MsgBox("Only numbers are allowed", MessageBoxIcon.Error, "Error")
        End Try
        'This statements tests to see if user entered negative grade value for grade 6
        If (grades(5) < 0) Then
            MsgBox("A grade cannot be negative", MessageBoxIcon.Error, "Error")
        End If

        'This for statement calculates total for grades
        For i As Integer = 0 To 5
            total += grades(i)
        Next

        mean = (total / 6) 'calculates mean

        'this statement checks to see if mean is less than 0
        If (mean < 0) Then
            MsgBox("You have entered one or more of the grades incorrectly", MessageBoxIcon.Error, "Error")
        End If

        txtMean.Text = Math.Round(Val(mean), 4)

        'this for statement calculates and stores grades squared
        For i As Integer = 0 To 5
            gradesSquared(i) = (grades(i) ^ 2)
        Next

        totalSquared = total ^ 2
        totalSquaredDIV = (totalSquared / 6)

        'this for statement calculates the sum of the squared grades for variance
        For i As Integer = 0 To 5
            totalSquaredSUM += gradesSquared(i)
        Next

        variance = ((totalSquaredSUM - totalSquaredDIV) / 5)
        txtVariance.Text = Math.Round(Val(variance), 4)

        SD = Sqrt(variance)
        txtSD.Text = Math.Round(Val(SD), 4)

        'These if statements calculate the letter grade based on the mean score
        If (mean >= 94) Then
            LG = "A"
            txtLG.Text = LG
        ElseIf (mean >= 88 And mean < 94) Then
            LG = "B+"
            txtLG.Text = LG
        ElseIf (mean >= 82 And mean < 88) Then
            LG = "B"
            txtLG.Text = LG
        ElseIf (mean >= 76 And mean < 82) Then
            LG = "C+"
            txtLG.Text = LG
        ElseIf (mean >= 70 And mean < 86) Then
            LG = "C"
            txtLG.Text = LG
        ElseIf (mean >= 64 And mean < 70) Then
            LG = "D"
            txtLG.Text = LG
        ElseIf (mean < 64 And mean >= 0) Then
            LG = "F"
            txtLG.Text = LG
        Else
            MsgBox("You have entered one or more of the grades incorrectly", MessageBoxIcon.Error, "Error")
        End If

    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click

    End Sub
End Class
